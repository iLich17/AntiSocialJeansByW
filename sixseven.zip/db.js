'use strict';
// Локальная база данных на компьютере (SQLite, встроенный модуль node:sqlite).
// Хранит учётную запись владельца: название компании и хэш пароля для входа без интернета.
// Пароль в открытом виде не хранится никогда.
const crypto = require('crypto');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const norm = (e) => String(e || '').trim().toLowerCase();

function hashPw(password, saltHex) {
  return crypto.scryptSync(String(password), Buffer.from(saltHex, 'hex'), 32).toString('hex');
}

function open(file) {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec(`CREATE TABLE IF NOT EXISTS accounts (
    email      TEXT PRIMARY KEY,
    user_id    TEXT,
    company    TEXT NOT NULL,
    pw_salt    TEXT NOT NULL,
    pw_hash    TEXT NOT NULL,
    confirmed  INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_login TEXT
  )`);

  const get = db.prepare('SELECT * FROM accounts WHERE email = ?');
  const insert = db.prepare(`INSERT INTO accounts (email, user_id, company, pw_salt, pw_hash, confirmed, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(email) DO UPDATE SET company = excluded.company, pw_salt = excluded.pw_salt,
      pw_hash = excluded.pw_hash, user_id = COALESCE(excluded.user_id, accounts.user_id),
      confirmed = MAX(accounts.confirmed, excluded.confirmed)`);

  function check({ email, password, company }, needCompany) {
    const e = norm(email);
    if (!EMAIL_RE.test(e)) return { ok: false, error: 'bad_email' };
    if (typeof password !== 'string' || password.length < 8 || password.length > 200) return { ok: false, error: 'bad_password' };
    if (needCompany) {
      const c = String(company || '').trim();
      if (!c || c.length > 80) return { ok: false, error: 'bad_company' };
    }
    return null;
  }

  return {
    // Регистрация: запись создаётся как «не подтверждена», пока не введён код из письма.
    register(a) {
      const bad = check(a, true); if (bad) return bad;
      const salt = crypto.randomBytes(16).toString('hex');
      insert.run(norm(a.email), null, String(a.company).trim(), salt, hashPw(a.password, salt), 0, new Date().toISOString());
      return { ok: true };
    },
    // Код подтверждён — аккаунт становится рабочим.
    confirm({ email, userId }) {
      const e = norm(email);
      if (!get.get(e)) return { ok: false, error: 'not_found' };
      db.prepare('UPDATE accounts SET confirmed = 1, user_id = ?, last_login = ? WHERE email = ?')
        .run(userId ? String(userId) : null, new Date().toISOString(), e);
      return { ok: true };
    },
    // После успешного входа через облако: обновляем локальную копию (в т.ч. на новом компьютере).
    touch(a) {
      const bad = check(a, true); if (bad) return bad;
      const salt = crypto.randomBytes(16).toString('hex');
      const now = new Date().toISOString();
      insert.run(norm(a.email), a.userId ? String(a.userId) : null, String(a.company).trim(), salt, hashPw(a.password, salt), 1, now);
      db.prepare('UPDATE accounts SET last_login = ?, confirmed = 1 WHERE email = ?').run(now, norm(a.email));
      return { ok: true };
    },
    // Вход без интернета: сверяем пароль с локальным хэшем.
    login(a) {
      const bad = check(a, false); if (bad) return bad;
      const row = get.get(norm(a.email));
      if (!row || !row.confirmed) return { ok: false, error: 'not_found' };
      const given = Buffer.from(hashPw(a.password, row.pw_salt), 'hex');
      const real = Buffer.from(row.pw_hash, 'hex');
      if (given.length !== real.length || !crypto.timingSafeEqual(given, real)) return { ok: false, error: 'wrong_password' };
      db.prepare('UPDATE accounts SET last_login = ? WHERE email = ?').run(new Date().toISOString(), row.email);
      return { ok: true, company: row.company, userId: row.user_id };
    },
    info(email) {
      const r = get.get(norm(email));
      return r ? { ok: true, company: r.company, confirmed: !!r.confirmed, createdAt: r.created_at, lastLogin: r.last_login } : { ok: false, error: 'not_found' };
    },
    close() { db.close(); }
  };
}

module.exports = { open };
