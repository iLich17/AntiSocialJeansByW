const { contextBridge, ipcRenderer } = require('electron');

const call = (name) => (arg) => ipcRenderer.invoke('compassdb:' + name, arg);

contextBridge.exposeInMainWorld('compassDB', {
    register: call('register'),
    confirm: call('confirm'),
    touch: call('touch'),
    login: call('login'),
    info: call('info'),
    openOAuthUrl: (url) => ipcRenderer.invoke('compass:open-oauth-url', url),
    onOAuthCallback: (callback) => {
        if (typeof callback !== 'function') return () => {};
        const listener = (_event, url) => callback(url);
        ipcRenderer.on('compass:oauth-callback', listener);
        return () => ipcRenderer.removeListener('compass:oauth-callback', listener);
    }
});
