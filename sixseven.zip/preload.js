const { contextBridge, ipcRenderer } = require('electron');

const call = (name) => (arg) => ipcRenderer.invoke('compassdb:' + name, arg);

contextBridge.exposeInMainWorld('compassDB', {
    register: call('register'),
    confirm: call('confirm'),
    touch: call('touch'),
    login: call('login'),
    info: call('info')
});
