# Compass — Electron + Supabase

## Подключение к облачной базе
Проект использует Supabase Auth и схему `supabase/schema.sql`, синхронизируя компании, товары, заказы и позиции заказов с PostgreSQL. Локальная SQLite-база остаётся только для автономного входа (хэш пароля); рабочие товары и заказы хранятся в Supabase.

### Первичная настройка
1. Создайте/откройте проект Supabase.
2. Откройте SQL Editor и выполните **целиком** `supabase/schema.sql` (это миграция `202611200001_initial_compass_schema.sql`).
3. В `Authentication → Providers → Email` включите подтверждение почты. Шаблон письма должен содержать `{{ .Token }}`, длина OTP — 6.
4. Проверьте `supabase-config.js`: `url` и publishable/anon key должны относиться к вашему проекту.
5. Установите зависимости и запустите приложение: `npm install`, `npm start`.

### Что синхронизируется
- Профиль и компании — `profiles`, `companies`, `memberships`, `company_settings`.
- Каталог — `products` (поля интерфейса категории/фото/характеристик сохраняются в `custom_fields`).
- Заказы и позиции — `orders`, `order_items`.
- Доступ изолирован по `company_id` политиками RLS.

### Важные ограничения
- Локальная SQLite-база не является репликой каталога: без интернета приложение может пройти локальную проверку учётных данных, но облачные товары и заказы недоступны.
- Сотрудники в текущем интерфейсе пока локальные; для реальных отдельных аккаунтов требуется доверенная Edge Function и приглашения Supabase Auth.
- Фото товаров пока сохраняются в структуре приложения, но загрузка бинарных файлов в Supabase Storage требует отдельной настройки bucket и политик.
- Перед промышленным использованием необходимо проверить политики RLS, особенно операции изменения состава заказов и складские движения, и прогнать pgTAP-тесты.

## Команды
```
npm install
npm start
npm run test:db
npm run make
```

### Диагностика связи с облаком
На экране входа доступна кнопка **«Проверить связь с облаком»**. Она проверяет доступность Auth endpoint проекта и показывает конкретную причину сбоя. Если локальная копия SDK не установлена/не загрузилась, приложение пробует загрузить SDK с официального CDN jsDelivr. Для этого сеть должна разрешать `cdn.jsdelivr.net` и `*.supabase.co`.

Если проверка сообщает о сетевой ошибке:
- убедитесь, что проект не приостановлен в Supabase Dashboard;
- сверьте URL и publishable key в `supabase-config.js` с настройками именно этого проекта;
- проверьте DNS/прокси/VPN/межсетевой экран; при `NXDOMAIN` проверьте project reference и попробуйте другую сеть;
- выполните `npm install` в каталоге проекта, затем `npm start`.


## Вход через Google (Electron)

В приложении используется OAuth через системный браузер и deep link `compass://auth/callback`.
Для работы необходимо:

1. В Supabase → Authentication → URL Configuration добавить `compass://auth/callback` в **Redirect URLs**.
2. В Supabase → Authentication → Providers → Google включить Google и сохранить Google Client ID и Client Secret.
3. В Google Cloud OAuth Client оставить Authorized redirect URI:
   `https://qkfblgoilsyejxeybrxe.supabase.co/auth/v1/callback`
4. Пересобрать и установить приложение. При первом запуске Windows может спросить, разрешить ли открыть Compass по ссылке `compass://`.

Client Secret хранится только в настройках Supabase и не должен попадать в приложение или репозиторий.
