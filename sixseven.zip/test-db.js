// Проверка локальной базы без запуска окна: npm run test:db
const assert = require('assert');
const os = require('os');
const path = require('path');
const fs = require('fs');
const file = path.join(os.tmpdir(), 'compass-test-' + Date.now() + '.db');
const db = require('./db').open(file);
const a = { email: ' Test@Mail.ru ', password: 'secret123', company: 'Свечи' };
assert.strictEqual(db.register(a).ok, true);
assert.strictEqual(db.login(a).ok, false, 'до подтверждения почты вход закрыт');
assert.strictEqual(db.confirm({ email: 'test@mail.ru', userId: 'u1' }).ok, true);
assert.strictEqual(db.login({ email: 'test@mail.ru', password: 'secret123' }).company, 'Свечи');
assert.strictEqual(db.login({ email: 'test@mail.ru', password: 'wrong-pass' }).ok, false);
assert.strictEqual(db.register({ email: 'x', password: '12345678', company: 'a' }).ok, false);
assert.strictEqual(db.register({ email: 'a@b.ru', password: '123', company: 'a' }).ok, false);
db.close();
for (const f of [file, file + '-wal', file + '-shm']) { try { fs.unlinkSync(f); } catch (e) {} }
console.log('Локальная база: все проверки пройдены');
