
window.COMPASS_SUPABASE_CONFIG = {
  url: "https://qkfblgoilsyejxeybrxe.supabase.co",
  anonKey: "sb_publishable_efw3b0z_-6K_xuvNFd_eZg_YFOzeLY6"
};
