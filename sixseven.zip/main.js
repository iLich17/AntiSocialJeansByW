const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');

let accounts = null; // локальная база данных (SQLite)
let mainWindow = null;
let pendingOAuthUrl = null;
const OAUTH_SCHEME = 'compass';

function sendOAuthCallback(url) {
    if (!url || !url.startsWith('compass://auth/callback')) return;
    if (mainWindow && !mainWindow.isDestroyed() && mainWindow.webContents.isLoading() === false) {
        mainWindow.webContents.send('compass:oauth-callback', url);
    } else {
        pendingOAuthUrl = url;
    }
}

function handleDeepLink(argv) {
    const url = (argv || []).find(v => typeof v === 'string' && v.startsWith('compass://auth/callback'));
    if (url) sendOAuthCallback(url);
}

function openLocalDb() {
    try {
        const file = path.join(app.getPath('userData'), 'compass.db');
        accounts = require('./db').open(file);
        console.log('[Compass] Локальная база данных:', file);
    } catch (e) {
        accounts = null;
        console.error('[Compass] Локальная база данных недоступна:', e.message);
    }
}

// Каналы связи окна с локальной базой. Окно получает только эти действия.
function handle(name) {
    ipcMain.handle('compassdb:' + name, (_e, arg) => {
        if (!accounts) return { ok: false, error: 'nodb' };
        try { return accounts[name](arg || {}); }
        catch (e) { return { ok: false, error: 'db_error' }; }
    });
}
['register', 'confirm', 'touch', 'login', 'info'].forEach(handle);

function createWindow() {
    const win = new BrowserWindow({
        width: 1400,
        height: 900,
        minWidth: 900,
        minHeight: 600,
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true
        }
    });

    // Внешние ссылки открываем в браузере, а не в окне приложения.
    win.webContents.setWindowOpenHandler(({ url }) => {
        if (/^https:\/\//.test(url)) shell.openExternal(url);
        return { action: 'deny' };
    });

    mainWindow = win;
    win.webContents.on('did-finish-load', () => {
        if (pendingOAuthUrl) {
            const url = pendingOAuthUrl;
            pendingOAuthUrl = null;
            win.webContents.send('compass:oauth-callback', url);
        }
    });
    win.on('closed', () => { if (mainWindow === win) mainWindow = null; });
    win.loadFile('index.html');
}

app.whenReady().then(() => {
    openLocalDb();
    if (app.isPackaged) {
        app.setAsDefaultProtocolClient(OAUTH_SCHEME);
    } else {
        // Register the scheme for `npm start` / Electron Forge development runs.
        app.setAsDefaultProtocolClient(OAUTH_SCHEME, process.execPath, [path.resolve(process.argv[1])]);
    }
    handleDeepLink(process.argv);
    createWindow();
});

app.on('open-url', (event, url) => {
    event.preventDefault();
    sendOAuthCallback(url);
});

app.on('second-instance', (_event, commandLine) => {
    if (mainWindow) {
        if (mainWindow.isMinimized()) mainWindow.restore();
        mainWindow.focus();
    }
    handleDeepLink(commandLine);
});

// Renderer may open only the project's Supabase OAuth authorize URL.
// Arbitrary URLs are rejected; normal links continue through setWindowOpenHandler.
ipcMain.handle('compass:open-oauth-url', async (_event, rawUrl) => {
    let u;
    try { u = new URL(rawUrl); } catch (_) { throw new Error('Некорректная ссылка авторизации'); }
    if (u.protocol !== 'https:' ||
        u.hostname !== 'qkfblgoilsyejxeybrxe.supabase.co' ||
        u.pathname !== '/auth/v1/authorize') {
        throw new Error('Разрешена только ссылка авторизации Compass в Supabase');
    }
    await shell.openExternal(u.toString());
    return { ok: true };
});

app.on('window-all-closed', () => {
    if (accounts) { try { accounts.close(); } catch (e) {} }
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
