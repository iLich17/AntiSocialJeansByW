const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');

let accounts = null; // локальная база данных (SQLite)

function openLocalDb() {
    try {
        const file = path.join(app.getPath('userData'), 'compass.db');
        accounts = require('./db').open(file);
        console.log('[Compass] Локальная база данных:', file);
    } catch (e) {
        accounts = null;
        console.error('[Compass] Локальная база данных недоступна:', e.message);
    }
}

// Каналы связи окна с локальной базой. Окно получает только эти действия.
function handle(name) {
    ipcMain.handle('compassdb:' + name, (_e, arg) => {
        if (!accounts) return { ok: false, error: 'nodb' };
        try { return accounts[name](arg || {}); }
        catch (e) { return { ok: false, error: 'db_error' }; }
    });
}
['register', 'confirm', 'touch', 'login', 'info'].forEach(handle);

function createWindow() {
    const win = new BrowserWindow({
        width: 1400,
        height: 900,
        minWidth: 900,
        minHeight: 600,
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true
        }
    });

    // Внешние ссылки открываем в браузере, а не в окне приложения.
    win.webContents.setWindowOpenHandler(({ url }) => {
        if (/^https:\/\//.test(url)) shell.openExternal(url);
        return { action: 'deny' };
    });

    win.loadFile('index.html');
}

app.whenReady().then(() => {
    openLocalDb();
    createWindow();
});

app.on('window-all-closed', () => {
    if (accounts) { try { accounts.close(); } catch (e) {} }
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
